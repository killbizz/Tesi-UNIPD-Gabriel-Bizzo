# Tesi UNIPD Gabriel Bizzo
 Tesi di laurea triennale al corso di laurea in informatica di Gabriel Bizzo, UNIPD, anno accademico 2020-2021
